//
//  ViewController.swift
//  iWord
//
//  Created by 何纪栋 on 2024/7/18.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

