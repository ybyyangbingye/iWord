//
//  Extension.swift
//  iWord
//
//  Created by 何纪栋 on 2024/7/18.
//

import Foundation

let kFruit: [String] = ["Apple","Orange","Banana","Banana","Watermelon","Pineapple","Peach","Peach"]
